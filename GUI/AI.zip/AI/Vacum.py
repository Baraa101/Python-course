import time
class Vacum:

    def __init__(self, canvas, window, size, xVelocity, color, locationA, locationB):
        self.canvas = canvas
        self.canWidth = canvas.winfo_width()
        self.center=(200-size)/2
        self.window = window
        self.image = canvas.create_rectangle(
            self.center, self.center, self.center+size, self.center+size, fill=color)
        self.xvelocity = xVelocity
        self.locatonA=locationA
        self.locatonB=locationB
        self.location = locationA
    
    def moveRight(self):
        if(self.location == self.locatonA):
            self.location = self.locatonB
            for i in range(40):
                cords = self.canvas.coords(self.image)
                self.canvas.move(self.image, self.xvelocity, 0)
                self.window.update()
                time.sleep(0.01)
            
        
            
    def moveLeft(self):
        if (self.location == self.locatonB):
            self.location = self.locatonA
            for i in range(40):
                cords = self.canvas.coords(self.image)
                self.canvas.move(self.image, -self.xvelocity, 0)
                self.window.update()
                time.sleep(0.01)

    def suck(self):
        if (not self.location.clean):
            self.location.clean = True
            self.canvas.itemconfig(self.location.rect, fill='green')

    def precept(self):
        if (not self.location.clean):
            self.suck()
        elif (self.location.symbol=='A'):
            self.moveRight()
        elif (self.location.symbol=='B'):
            self.moveLeft()