# Imports and initalization
from tkinter import *
import time
from Vacum import *
import threading
import random

WIDTH = 400
HEIGHT = 200


class Location:
    def __init__(self, rect,symbol):
        self.rect = rect
        self.clean = True
        self.symbol = symbol


window = Tk()

canvas = Canvas(window, width=WIDTH, height=HEIGHT)
canvas.pack()

locationA = Location(canvas.create_rectangle(0, 0, 200, 200, fill="Green"),'A')
locationB = Location(canvas.create_rectangle(200, 0, 400, 200, fill="Green"),'B')
vacum = Vacum(canvas,window, 50, 5, "pink",locationA,locationB)
 

l=True
def move():
    global l
    threading.Timer(2.0,move).start()
    vacum.precept()
    """ if(l):
         vacum.moveRight()
         l = False
    else:
        vacum.moveLeft()
        l = True """

def dirt():
    a = random.randint(0, 1)
    threading.Timer(3.0, dirt).start()
    if(a==0 and locationA.clean):
        locationA.clean = False
        canvas.itemconfig(locationA.rect,fill='red')
    a = random.randint(0, 1)
    if (a == 0 and locationB.clean):
        locationB.clean = False
        canvas.itemconfig(locationB.rect, fill='red')

move()
dirt()

""" vacum.moveUp() """

""" canvas.create_rectangle(0, 200, 201, 400, fill="Green") """


window.mainloop()
